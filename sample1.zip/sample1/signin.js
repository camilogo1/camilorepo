define([
  'jquery',
  'underscore',
  'backbone',
  '../../collections/signin',
  'text!../../../../../templates/signIn.html'
], function($, _, Backbone, SignInCollection, SignInTemplate){
  var that = this,
  SignInView = Backbone.View.extend({
    el: $('#appContainer'),
    initialize: function() {
      SignInCollection.on('change', this.render, this);
      this.render();
    },
    render: function(){
      // Target type will determine response
      /// 0 = sign in
      /// 1 = sign up
      /// 2 = delete
      data = {
        logStatus: SignInCollection.at(0).toJSON().logStatus
      };
      var signedInTemplate = _.template( SignInTemplate, data );
      this.$el.html( signedInTemplate );
    },
    events: {
        'click #signin' : 'signinSubmit',
        'click #signup' : 'signupSubmit'
      },
      signinSubmit: function(){
        //SignInCollection.send();
        var testVar = SignInCollection.at(0).set({'userid':$('#userid').val()});
        console.log('testVars is ', testVar.get('userid'));
      },
      signupSubmit: function(){
        //SignInCollection.send();
        var myModel = SignInCollection.at(1),
        myUserId = $('#userId2').val();
        myModel.set({'userid2':myUserId});
        myModel.save();
        console.log('myModel is>>>>>>>> ', myModel.get('userid2'));
      },
    });
  return SignInView;
});
console.log('SignInView module');
