/*Function to add or subtract video fields 
  as needed and make them mandatory.
  Listener functions must be passed in
  as the property of an object. 
*/
var VidCarouObj = {};
VidCarouObj.vidAnimation = false;
VidCarouObj.manageDropdown = function (comp) {
    "use strict";
    var selectionNumber = comp.hiddenField.value,
        panel = comp.findParentByType('panel'),
        tagitem, tagitemState, vidNumState,vidType,vidNum,
        NUMBER_OF_VIDEOS = 8;
    //initialize array and destroy old numbers
    for (var i = 0; i < NUMBER_OF_VIDEOS ; i++) {
        tagitemState = panel.items.items[2].items.items[i];
        vidNumState = tagitemState.items.items[1];
        vidNum = tagitemState.items.items[1].value;
        vidType = tagitemState.items.items[0].value;
        if  (i < selectionNumber) {
            tagitemState.show();
			tagitemState.expand(true);
			vidNumState.allowBlank=false;
        } else {
            tagitemState.collapse(true);
            tagitemState.hide();
            vidNumState.allowBlank=true;
        }
    }
};
  /*
}
Video Component for expoTV and YouTube videos.
*/
function vidCarouPopulate(vidType,vidNum,vidWidth,thisHold) {
    "use strict";
	var vidHtml,
    vidCarouselType = vidType,
	vidDimensons = vidCarouFormat(vidWidth),
	VIDEO_GUTTER = 50,
	VIDEO_FRAME_OUTLINE = 18,
    subSectionWidth = Number(vidWidth) + VIDEO_GUTTER,
    thisInstanceNum = thisHold.substring(13),
    thisInstance = '.video-' + thisInstanceNum,
    thisVidRight = thisInstance + ' .videoHolderRight',
    thisVidLeft = thisInstance + ' .videoHolderLeft',
	thisSectLeft = thisInstance + ' .vidCarouSubsectLeft',
	thisSectRight = thisInstance + ' .vidCarouSubsectRight';
	if ($(thisVidRight)) {
		//$(thisSectLeft).css('margin-right', subSectionWidth + 'px');
		// Set height of left text section to have it vertically center
		$(thisSectLeft).css('height',parseInt(vidDimensons.vidHeight,10)+VIDEO_FRAME_OUTLINE);
    }
    if ($(thisVidLeft)) {
		//$(thisSectRight).css('margin-left', subSectionWidth + 'px');
		// Set height of left text section to have it vertically center
		$(thisSectRight).css('height',parseInt(vidDimensons.vidHeight,10)+VIDEO_FRAME_OUTLINE);
    }
	switch(vidType){
		case 'expoTv':
			vidHtml = '<iframe class="vidframe" width="'+vidDimensons.vidWidth+'" height="'+vidDimensons.vidHeight+'" scrolling="no" frameborder="0" id="mp_frame_757" allowtransparency="yes" src="http://client.expotv.com/video/embed/v5/'+vidNum+'/59b8038e62f9f167658e77c77ebf6adc?autostart=false&amp;width='+vidDimensons.vidWidth+'height='+vidDimensons.vidHeight+'&amp;title="></iframe>';
			break;
		case 'youTube':
			vidHtml = '<iframe class="vidframe" width="'+vidDimensons.vidWidth+'" height="'+vidDimensons.vidHeight+'" src="http://www.youtube.com/embed/'+vidNum+'" frameborder="0" allowfullscreen></iframe>';
			break;
	}
	$(thisHold).html(vidHtml);
}

/*Creates 
  a video carousel array for later use 
  in thumbnails, etc.
*/
function createVidCarouselArray(vidList) {
    "use strict";
	var vidCarouselArray = vidList.split(','),
    vidListLength = vidCarouselArray.length;
	for (var i=0; i<vidListLength;i++) {
		vidCarouselArray[i/3] = [vidCarouselArray[i],vidCarouselArray[++i],vidCarouselArray[++i]];
	}
	return vidCarouselArray;
}

$.fn.carouselPopulate = function(vidQuan,thisHold,vidList,vidWidth,thisContain) {
    "use strict";
	var vidCarouHTML='',
	vidCarouselArray = createVidCarouselArray(vidList);
    //thisClass = this.attr('class').substring(0,48);
	for (var i=0 ; i<vidQuan; i++){
        if (vidQuan > 1 && vidCarouselArray[i][1]) {
            var vidCarrier = vidCarouselArray[i][0].trim();
            switch(vidCarrier){
                case 'youTube':
                    vidCarouHTML += parseVidCarouYouTube(vidCarouselArray[i][1].trim(),vidCarouselArray[i][2].trim(),thisHold);
                break;
                case 'expoTv':
                    vidCarouHTML += parseVidCarouExpoTv(vidCarouselArray[i][1].trim(),vidCarouselArray[i][2].trim(),thisHold);
                break;
            }
        }
    }
	this.html(vidCarouHTML);
	this.on('click', 'img', {'vidWidth':vidWidth}, vidCarouHandler);
	this.parent().parent().on('click', 'span', {'carousel':this, 'vidQuan':vidQuan, 'thisContain':thisContain}, vidCarouScroller);
	dotInit(vidQuan,thisContain);
    $('.vidcarousel div.vidCarouImg:first-child  img').css('opacity', 1);
};

function vidCarouScroller(e) {
    "use strict";
	var carousel = e.data.carousel,
	vidQuan = e.data.vidQuan,
	thisContain = e.data.thisContain,
	dotContain = thisContain + ' .dotHolder ul',
	carouselX = carousel.position().left,
    absCarouselX = Math.abs(carouselX),
    VID_THUMB_WIDTH = 86,
	carouselMax = vidQuan * VID_THUMB_WIDTH;
	// Check to see if carousel is animating. If so, prevent double clicks.
	if (VidCarouObj.vidAnimation === false) {
		VidCarouObj.vidAnimation = true;
		if ($( e.target ).hasClass('vidcarouleft')) {
            $(thisContain + ' .vidcarouRight').removeClass('vidcarouRightDim');
            if(absCarouselX <= 4*VID_THUMB_WIDTH) {
                $(thisContain + ' .vidcarouleft').addClass('vidcarouleftDim');
            }
			if(carouselX < 0) {
				carousel.animate({
					left:'+=312'},
					400,
					'swing',
					function() {VidCarouObj.vidAnimation = false;}
				);
				$( dotContain ).find('.drkDot').removeClass('drkDot').addClass('lghtDot').prev().addClass('drkDot').removeClass('lghtDot');
			} else {
				VidCarouObj.vidAnimation = false;
			}
		} else {
			// TODO 4 and 7 videos break my algorithym, 
			// come up with better one.
			$(thisContain + ' .vidcarouleft').removeClass('vidcarouleftDim');
			if (vidQuan === '4') {carouselMax = 279;}
			if (vidQuan === '7') {carouselMax = 8*VID_THUMB_WIDTH;}
			if(absCarouselX >= carouselMax - 4*VID_THUMB_WIDTH) {
                $(thisContain + ' .vidcarouRight').addClass('vidcarouRightDim');
            }
			if(absCarouselX <= carouselMax) {
				carousel.animate({left:'-=312'},
					400,
					'swing',
					function() {VidCarouObj.vidAnimation = false;}
				);
				$( dotContain ).find('.drkDot').removeClass('drkDot').addClass('lghtDot').next().addClass('drkDot').removeClass('lghtDot');
			} else {
				VidCarouObj.vidAnimation = false;
			}
		}
	}
}

function vidCarouHandler(e) {
    "use strict";
	var imgTarget = e.target,
    thumbAnim = false,
    vidNum = imgTarget.attributes['data-vidNum'].value,
	vidWidth = e.data.vidWidth,
	thisHold = imgTarget.attributes['data-thisHold'].value,
    imgArray = $( imgTarget ).parent().parent().find('img'),
    imgArrayLen = imgArray.length + 1,
    imgArrayItem,
    i = 0;
    for (i; i<imgArrayLen; i++) {
		imgArrayItem = $(imgArray[i]);
        if (imgArrayItem.css('opacity') > 0.5) {
            imgArrayItem.css('opacity', 0.5);
        } else if ($(imgTarget).css('opacity') <= 1) {
            //thumbAnim = true;
            $(imgTarget).css('opacity',1);
        }
    }
    if (imgTarget.src.match(/youtube/)) {
        vidCarouPopulate('youTube',vidNum,vidWidth,thisHold);
    } else {
        vidCarouPopulate('expoTv',vidNum,vidWidth,thisHold);
    }
}

function parseVidCarouYouTube(vidNum,vidCap,thisHold) {
    "use strict";
	var parsedHTML = '<div class="vidCarouImg"><img src="http://img.youtube.com/vi/' + vidNum + '/1.jpg" data-vidNum="' + vidNum + '" data-thisHold="' + thisHold + '" style="cursor: pointer; cursor: hand;" /><div class ="vidCarouCaps">' + vidCap +'</div></div>';
	return parsedHTML;
}

function parseVidCarouExpoTv(vidNum,vidCap,thisHold) {
    "use strict";
	var numArray = vidNum.toString().split(''),
	urlNum = numArray[0]+'/'+numArray[1]+'/'+numArray[2]+'/'+vidNum;
	var parsedHTML = '<div class="vidCarouImg"><img src="http://videos.expotv.com/' + urlNum + '_ST.jpg?width=120&height=90&background_fill=000000" data-vidNum="' + vidNum + '" data-thisHold="' + thisHold + '" style="cursor: pointer; cursor: hand;" /><div class ="vidCarouCaps">' + vidCap +'</div></div>';
	return parsedHTML;
}
// Manages dot creation and updating
function dotInit(vidQuan,thisContain) {
    "use strict";
    var dotContain = thisContain + ' .dotHolder',
        dotNum = Math.ceil(vidQuan/2),
        i=1,
        widthClass = 'vidDot' + dotNum,
        dotHTML = '<ul class="'+ widthClass +'"><li class="drkDot">';
    for (i;i<dotNum;i++) {
        dotHTML += '<li class="lghtDot">';
    }
    dotHTML += '</ul>';
	$(dotContain).html(dotHTML);
}
// sorts out inline height & width based on parent container's width.
function vidCarouFormat(vidWidth){
    "use strict";
	var vidMaxWidth = 700,
	vidDenom = 1.778,
	vidRatio = '16:9';
	if (vidWidth === "" || vidWidth === null || vidWidth > vidMaxWidth) {
		vidWidth = vidMaxWidth;
	} else {
		vidWidth = vidWidth;
	}
	
	if(vidWidth<450){
		vidDenom = 1.333;
		vidRatio = '4:3';
	}
	
	var vidHeight = vidWidth/vidDenom;
	
	var vidDimensons = {
		'vidWidth' : vidWidth,
		'vidHeight' : vidHeight,
		'ratio' : vidRatio
	};
	
	return vidDimensons;

}

